﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace WebServiceMySql.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsuarioController : ControllerBase
    {

        [HttpPost]
        //O método abaixo será acessado via POST
        //e receberá um objeto "protudo" que será enviado
        //através do corpo/body, ou seja [FromBody]
        public IActionResult cadastrar([FromBody] Cliente cliente)
        {
            MySqlConnection conexao = new MySqlConnection
                ("Server=ESN509VMYSQL;Database=carrinho_tcc;User=aluno;password=Senai1234");
            MySqlCommand sql = new MySqlCommand
                ("INSERT INTO cliente(CPF_cliente,Email_cliente,CEP_cliente,Senha,Tipo_cliente,Nome_cliente,Telefone_cliente,UF_cliente,Num_endereco_cliente, Municipio_cliente,Bairro_cliente,Complemento_endereco_cliente)" +
                "VALUES(@c,@e,@cep,@s,@t,@n,@tel,@uf,@num,@m,@b,@com)", conexao);
            try
            {
                sql.Parameters.AddWithValue("@c", cliente.cpf);
                sql.Parameters.AddWithValue("@e", cliente.email);
                sql.Parameters.AddWithValue("@cep", cliente.cep);
                sql.Parameters.AddWithValue("@s", criptografar(cliente.senha));
                sql.Parameters.AddWithValue("@t", cliente.tipoCliente);
                sql.Parameters.AddWithValue("@n", cliente.nome);
                sql.Parameters.AddWithValue("@tel", cliente.telefone);
                sql.Parameters.AddWithValue("@uf", cliente.uf);
                sql.Parameters.AddWithValue("@num", cliente.num_endereco);
                sql.Parameters.AddWithValue("@m", cliente.municipio);
                sql.Parameters.AddWithValue("@b", cliente.bairro);
                sql.Parameters.AddWithValue("@com", cliente.complemento);

                conexao.Open();
                if (sql.ExecuteNonQuery() != 0)
                {

                    return Ok(new { result = "sucesso", status = 200 }); //Retorna OK (sucesso) e exibe o produto cadastrado
                    conexao.Close();
                }
                else
                {
                    return NoContent();
                    conexao.Close();
                }

            }
            catch (Exception)
            {
                throw;
                conexao.Close();
            }
        }

        //Método para validar o acesso (login) através do email e senha dentro do webservice
        //Os dados de email e senha serão passados via POST através do body e usando uma rota diferente
        [HttpPost()]
        [Route("/api/[controller]/login")] //Criando uma rota diferente pois o POST já é utilizado no método acima
        public IActionResult login([FromBody] Cliente cliente)
        {
            MySqlConnection con = new MySqlConnection("Server=ESN509VMYSQL;Database=carrinho_tcc;User=aluno;password=Senai1234");
            try
            {
                MySqlCommand sql = new MySqlCommand("SELECT senha FROM cliente WHERE Email_cliente = @e;", con);
                sql.Parameters.AddWithValue("@e", cliente.email);
                con.Open();

                MySqlDataReader reader = sql.ExecuteReader();
                while (reader.Read())
                {
                    if (criptografar(cliente.senha).Equals(reader.GetString("Senha")))
                    {
                        return Ok(new { result = "sucesso", status = 200 });
                    }
                    else
                    {
                        return NoContent();
                    }
                }

            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                con.Close();
            }
            return NoContent();
        }

        [HttpGet]
        public List<Cliente> Get()
        {
            List<Cliente> lista = new List<Cliente>();
            MySqlConnection conexao = new MySqlConnection
                ("Server=ESN509VMYSQL;Database=carrinho_tcc;User=aluno;password=Senai1234");
            MySqlCommand sql = new MySqlCommand("SELECT * FROM cliente", conexao);
            conexao.Open();
            MySqlDataReader reader = sql.ExecuteReader();
            while (reader.Read())
            {
                lista.Add(new Cliente(reader.GetString("CPF_cliente"), reader.GetString("Email_cliente"), reader.GetString("CEP_cliente"), reader.GetString("Senha"), reader.GetString("Tipo_cliente"), reader.GetString("Nome_cliente"),
                    reader.GetString("Telefone_cliente"), reader.GetString("UF_cliente"), reader.GetString("Num_endereco_cliente"), reader.GetString("Municipio_cliente"), reader.GetString("Bairro_cliente"), reader.GetString("Complemento_endereco_cliente")));
            }
            conexao.Close();
            return lista;
        }

        [HttpPut]
        public IActionResult atualizar([FromBody] Cliente cliente)
        {
            MySqlConnection con = new MySqlConnection("Server=ESN509VMYSQL;Database=carrinho_tcc;User=aluno;password=Senai1234");
            try
            {
                MySqlCommand cmd = new MySqlCommand("UPDATE cliente SET Nome_cliente = @nc, Email_cliente=@ec, Senha=@s, Telefone_cliente=@tc, CEP_cliente=@cep," +
                                                    "CPF_cliente=@cpf, Num_endereco_cliente=nec, UF_cliente=@uf, Bairro_cliente=@bc, Complemento_endereco_cliente=@cec WHERE CPF_cliente = @cpf;", con);
                cmd.Parameters.AddWithValue("@n", cliente.nome);
                cmd.Parameters.AddWithValue("@e", cliente.email);
                cmd.Parameters.AddWithValue("@s", criptografar(cliente.senha));
                cmd.Parameters.AddWithValue("@f", cliente.telefone);
                cmd.Parameters.AddWithValue("@d", cliente.cep);
                cmd.Parameters.AddWithValue("@id", cliente.num_endereco);
                cmd.Parameters.AddWithValue("@id", cliente.uf);
                cmd.Parameters.AddWithValue("@m", cliente.municipio);
                cmd.Parameters.AddWithValue("@b", cliente.bairro);
                cmd.Parameters.AddWithValue("@com", cliente.complemento);


                con.Open();
                if (cmd.ExecuteNonQuery() != 0)
                {
                    return Ok(new { result = "sucesso", status = 200 });
                }
                else
                {
                    return NoContent();
                }

            } catch (Exception)
            {
                throw;
            }finally
            {
                con.Close();
            }
        }
        [HttpDelete("{cpf}")]
        public IActionResult remover(int cpf)
        {
            MySqlConnection con = new MySqlConnection("Server=ESN509VMYSQL;Database=carrinho_tcc;User=aluno;password=Senai1234");
            try
            {
                MySqlCommand cmd = new MySqlCommand("DELETE FROM usuario WHERE CPF_cliente = @cpf;", con);
                cmd.Parameters.AddWithValue("@cpf", cpf);

                con.Open();
                if (cmd.ExecuteNonQuery() != 0)
                {
                    return Ok(new { result = "sucesso", status = 200 });
                }
                else
                {
                    return NoContent();
                }

            } catch (Exception)
            {
                throw;
            }finally
            {
                con.Close();
            }
        }

        private string criptografar(string senha)
        {
            //Criar um objeto da classe SHA256
            SHA256 sha256 = SHA256.Create();

            //Converte a senha para um vetor de bytes
            byte[] bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(senha));

            //Converter o vetor de bytes para String
            StringBuilder builder = new StringBuilder();
            for (int i = 0; i < bytes.Length; i++)
            {
                builder.Append(bytes[i].ToString("x2"));
            }

            //Retorna a senha em String
            return builder.ToString();
        }
    }
}
