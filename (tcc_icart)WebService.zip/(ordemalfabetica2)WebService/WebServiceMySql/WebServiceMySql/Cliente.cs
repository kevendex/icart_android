﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebServiceMySql
{
    public class Cliente
    {

        //Atributos 
        public string cpf { get; set; }
        public string email { get; set; }
        public string cep { get; set; }
        public string senha { get; set; }
        public string tipoCliente { get; set; }
        public string nome { get; set; }
        public string telefone { get; set; }
        public string uf { get; set; }
        public string num_endereco { get; set; }
        public string municipio { get; set; }
        public string bairro { get; set; }
        public string complemento { get; set; }

        //Construtor -> Ctrl .
        public Cliente() { }

        public Cliente(string cpf, string email, string cep, string senha, string tipoCliente, string nome, string telefone, string uf, string num_endereco, string municipio, string bairro, string complemento) {
            this.cpf = cpf;
            this.email = email;
            this.cep = cep;
            this.senha = senha;
            this.tipoCliente = tipoCliente;
            this.nome = nome;
            this.telefone = telefone;
            this.uf = uf;
            this.num_endereco = num_endereco;
            this.municipio = municipio;
            this.bairro = bairro;
            this.complemento = complemento;
        }

    }
}
