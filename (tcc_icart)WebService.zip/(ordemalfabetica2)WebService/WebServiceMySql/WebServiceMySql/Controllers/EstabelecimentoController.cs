﻿using Microsoft.AspNetCore.Mvc;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebServiceMySql.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EstabelecimentoController : Controller
    {

        [HttpGet]
        [Route("/api/[controller]/lista")] //Criando uma rota diferente pois o POST já é utilizado no método acima
        public List<Estabelecimento> Get() {
            List<Estabelecimento> lista = new List<Estabelecimento>();
            MySqlConnection conexao = new MySqlConnection
                ("Server=ESN509VMYSQL;Database=carrinho_tcc;User=aluno;password=Senai1234");
            MySqlCommand sql = new MySqlCommand("SELECT * FROM estabelecimento", conexao);
            conexao.Open();
            MySqlDataReader reader = sql.ExecuteReader();
            while (reader.Read()) {
                lista.Add(new Estabelecimento(reader.GetString("Bairro_estabel"), reader.GetString("Nome_Fantasia"), reader.GetString("Num_Endereco_estabel"),
                    reader.GetString("Municipio_estabel"), reader.GetString("Complemento_Endereco_estabel")));
            }
            conexao.Close();
            return lista;

        }



    }
    }

