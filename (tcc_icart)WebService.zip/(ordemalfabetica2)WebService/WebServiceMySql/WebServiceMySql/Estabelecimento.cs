﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebServiceMySql
{
    public class Estabelecimento
    {
        
         //atributos
       // public string codEstabelecimento { get; set; }        
       // public string tamanhoEstabelecimento { get; set; }
       // public string cepEstabelecimento { get; set; }
       // public string emailEstabelecimento { get; set; }      
       // public string nomeEmpresarial { get; set; }
       // public string telefoneEstabelecimnto { get; set; }      
       // public string logradouroEstabelecimento { get; set; }  
        // public string cnpjEstabelecimento { get; set; }
        // public string senhaEstabelecimento { get; set; }
        public string bairroEstabelecimento { get; set; }
        public string nomeFantasia { get; set; }
        public string numEstabelecimento { get; set; }
        public string municipioEstabelecimento { get; set; }
        public string complementoEstabelecimento { get; set; }


        //Construtor -> Ctrl .
        public Estabelecimento() { }

        public Estabelecimento(string bairroEstabelecimento, string nomeFantasia, string numEstabelecimento, string municipioEstabelecimento, string complementoEstabelecimento) {
            this.bairroEstabelecimento = bairroEstabelecimento;
            this.nomeFantasia = nomeFantasia;
            this.numEstabelecimento = numEstabelecimento;
            this.municipioEstabelecimento = municipioEstabelecimento;
            this.complementoEstabelecimento = complementoEstabelecimento;
        }
    }
}
