package com.example.icart_tcc;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.snackbar.Snackbar;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

public class MainActivity extends AppCompatActivity {

    Button btCadastro,btLogin;
    TextView txtEsqueceuSenha;
    EditText etxtEmail,etxtSenha;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide(); //tirar a barra
        setContentView(R.layout.activity_main);

        //Endereço do webservice hospedado no IIS
        String url ="http://10.0.2.2:5000/api/Produto";

        //Instanciando o objeto para requisição com a classe Volley
        RequestQueue queue = Volley.newRequestQueue(this);

        //Criando a requisição com o método GET e URL
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        //Exibindo o resultado
                        Log.d("LOG_WEBSERVICE", response);
                        Toast.makeText(MainActivity.this, "Conectado", Toast.LENGTH_SHORT).show();
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                //Exibindo mensagem caso aconteça algum erro
                Log.d("LOG_WEBSERVICE", "ERRADO: " + error.getMessage());
                Toast.makeText(MainActivity.this, "Facrassado", Toast.LENGTH_SHORT).show();
            }
        });

        //Adicionando a requisição para ser executada
        queue.add(stringRequest);

        //organizando elementos da tela
        etxtEmail = (EditText) findViewById(R.id.etxtEmail);
        etxtSenha = (EditText) findViewById(R.id.etxtPassword);
        txtEsqueceuSenha = (TextView) findViewById(R.id.esqueceu_senha);
        btCadastro = (Button) findViewById(R.id.btcadastro);
        btLogin = (Button) findViewById(R.id.btLogin);

        btCadastro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity.this, tela_cadastro.class);
                startActivity(i);
            }
        });

        //clicar no botão Login
        btLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                try {
                    JSONObject dadosEnvio = new JSONObject();
                    //O método de Login espera receber o E-mail e Senha
                    dadosEnvio.put("Email_cliente", etxtEmail.getText().toString());
                    dadosEnvio.put("Senha", etxtSenha.getText().toString());

                    //Configurar a requisição que será enviada ao webservice
                    JsonObjectRequest configRequisicao = new JsonObjectRequest(Request.Method.POST,
                            url, dadosEnvio,
                            new Response.Listener<JSONObject>() {
                                @Override
                                public void onResponse(JSONObject response) {
                                    try {
                                        if (response.getInt("status") == 200) {
                                            Snackbar.make(findViewById(R.id.container), "Logado!", Snackbar.LENGTH_SHORT).show();
                                            Intent it = new Intent(MainActivity.this, Home.class);
                                            startActivity(it);
                                        } else {
                                            Snackbar.make(findViewById(R.id.container), "Dados incorretos!", Snackbar.LENGTH_SHORT).show();
                                        }
                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                        Snackbar.make(findViewById(R.id.container), "Erro ao enviar os dados", Snackbar.LENGTH_SHORT).show();
                                    }
                                }
                            },
                            new Response.ErrorListener() {
                                @Override
                                public void onErrorResponse(VolleyError error) {
                                    error.printStackTrace();
                                    Snackbar.make(findViewById(R.id.container), "Erro ao enviar", Snackbar.LENGTH_SHORT).show();
                                }
                            }
                    );

                    RequestQueue requisicao = Volley.newRequestQueue(MainActivity.this);
                    requisicao.add(configRequisicao);

                } catch (Exception exc) {
                    exc.printStackTrace();
                }
            }
        });

                    /*
                }catch (JSONException jExc){
                    jExc.printStackTrace();
                }
                //Configurar o envio (juntar URL + dados + método - POST) e
                //configurar o que irá acontecer se der tudo certo ou ocorrer erro
                JsonObjectRequest config = new JsonObjectRequest(
                        Request.Method.POST, //Método de envio dos dados
                        url,//local do WebService
                        dadosEnvio, //O que será enviado
                        new Response.Listener<JSONObject>() {
                            @Override
                            public void onResponse(JSONObject response) {
                                //Verificar se o conteúdo retornado pelo webservice
                                //possui mesmo um objeto da classe Produto
                                if (response.has("email")) {
                                    Toast.makeText(MainActivity.this,
                                            "Deu certo!!", Toast.LENGTH_SHORT).show();
                                    Intent i = new Intent(MainActivity.this, Home.class);
                                    startActivity(i);
                                }
                            }
                        }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(MainActivity.this,
                                "Sem cadastro", Toast.LENGTH_SHORT).show();
                        error.printStackTrace();
                    }
                }
                );
                queue.add(config); */

        txtEsqueceuSenha.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity.this, telaesqueceusenha.class);
                startActivity(i);
            }

        });

    }

}