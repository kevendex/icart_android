package com.example.icart_tcc;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Carrinho extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_carrinho);
    }
}