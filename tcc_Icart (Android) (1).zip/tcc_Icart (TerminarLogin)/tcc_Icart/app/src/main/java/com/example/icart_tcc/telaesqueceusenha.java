package com.example.icart_tcc;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class telaesqueceusenha extends AppCompatActivity {

    ImageView imgsetaVoltar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide(); //tirar a barra
        setContentView(R.layout.activity_telaesqueceusenha);




        imgsetaVoltar = (ImageView) findViewById(R.id.imgsetavoltar);

        imgsetaVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(telaesqueceusenha.this, MainActivity.class);
                startActivity(i);
            }
        });

    }
}