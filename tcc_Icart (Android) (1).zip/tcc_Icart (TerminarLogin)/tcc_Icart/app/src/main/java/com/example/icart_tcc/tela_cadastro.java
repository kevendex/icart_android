package com.example.icart_tcc;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.MaskFilter;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.snackbar.Snackbar;

import org.json.JSONException;
import org.json.JSONObject;

public class tela_cadastro extends AppCompatActivity {

    Button btVoltar;
    Button btCadastrar;
    EditText edtxtNome;
    EditText edtxtCEP;
    EditText edtxtTelefone;
    EditText edtxtCpf;
    EditText edtxtEmail;
    EditText edtxtSenha;
    EditText edtxtConfirmarSenha;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide(); //tirar a barra
        setContentView(R.layout.activity_tela_cadastro);


        edtxtNome = (EditText) findViewById(R.id.edtxtNome);
        edtxtCEP = (EditText) findViewById(R.id.edtxtCEP);
        edtxtTelefone = (EditText) findViewById(R.id.edtxtTelefone);
        edtxtCpf = (EditText) findViewById(R.id.edtxtCpf);
        edtxtEmail = (EditText) findViewById(R.id.etxtEmail);
        edtxtSenha = (EditText) findViewById(R.id.edtxtSenha);
        edtxtConfirmarSenha = (EditText) findViewById(R.id.edtxtConfirmarSenha);

        btVoltar = (Button) findViewById(R.id.btvoltar);
        btCadastrar = (Button) findViewById(R.id.btCadastrar);

        //Criar um objeto da classe Volley para configurar as requisições ao webservice
        RequestQueue queue = Volley.newRequestQueue(this);
        //Configuração do endpoint (url) da requisição
        String url = "http://10.0.2.2:5000/api/User/GetAllUsers";

        btCadastrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Criar um objeto para passar os parâmetros a serem enviados
                JSONObject enviar = new JSONObject();
                try {
                    //Passar parâmetros por valor
                    enviar.put("nome", edtxtNome.getText().toString());
                    enviar.put("CEP", edtxtCEP.getText().toString());
                    enviar.put("telefone", edtxtTelefone.getText().toString());
                    enviar.put("CPF", edtxtCpf.getText().toString());
                    enviar.put("Email", edtxtEmail.getText().toString());
                    enviar.put("Senha", edtxtSenha.getText().toString());
                    enviar.put("Senha", edtxtConfirmarSenha.getText().toString());

                }catch (JSONException e) {
                    e.printStackTrace();
                }

                //Configurar a requisição
                JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST,
                        url + "cadastrar", enviar, new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        //Recuperar a resposta do webservice
                        if(response.has("nome")){
                            //Ajustar Manifest para a Snackbar aparecer sobre o teclado (na Activity)
                            //android:windowSoftInputMode="adjustResize"
                            Snackbar.make(tela_cadastro.this, findViewById(R.id.tela), "Cadastrado", Snackbar.LENGTH_SHORT).show();
                        }
                        Log.d("APP_MYSQL", ">>>>>>>>>>>>>>>>> " + response.toString());

                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(tela_cadastro.this, "Erro ao conectar", Toast.LENGTH_SHORT).show();
                        Log.d("APP_MYSQL", ">>>>>>>>>>>>>>>>> " + error.getMessage());
                    }
                });
                //Pedir para a requisição ser enviada e executada
                queue.add(request);
            }
        });


        btVoltar.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            Intent i = new Intent(tela_cadastro.this, MainActivity.class);
            startActivity(i);
        }
    });

    }
}