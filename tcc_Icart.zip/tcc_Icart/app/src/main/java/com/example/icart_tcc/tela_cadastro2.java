package com.example.icart_tcc;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.snackbar.Snackbar;

import org.json.JSONException;
import org.json.JSONObject;

public class tela_cadastro2 extends AppCompatActivity {

    Button btCadastro, btVoltarHome;
    EditText tvMunicipio, tvNumero, tvBairro, tvComplemento;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_cadastro2);

        //Criar um objeto da classe Volley para configurar as requisições ao webservice
        RequestQueue queue = Volley.newRequestQueue(this);
        //Configuração do endpoint (url) da requisição
        String url = "http://10.0.2.2:5000/api/Produto";

        //Pegando os dados da tela anterior com Bundle
        Bundle dados = getIntent().getExtras();
        String nome = dados.getString("nome");
        String uf = dados.getString("uf");
        String cep = dados.getString("cep");
        String telefone = dados.getString("telefone");
        String cpf = dados.getString("cpf");
        String email = dados.getString("email");
        String senha = dados.getString("senha");

        btCadastro = findViewById(R.id.btCadastro);
        btVoltarHome = findViewById(R.id.btVoltarHome);
        tvMunicipio = findViewById(R.id.tvMunicipio);
        tvNumero = findViewById(R.id.tvNumero);
        tvBairro = findViewById(R.id.tvBairro);
        tvComplemento = findViewById(R.id.tvComplemento);

        btCadastro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                JSONObject enviar = new JSONObject();
                try {
                    enviar.put("municipio", tvMunicipio.getText().toString());
                    enviar.put("num_endereco", tvNumero.getText().toString());
                    enviar.put("bairro", tvBairro.getText().toString());
                    enviar.put("nome", nome);
                    enviar.put("uf", uf);
                    enviar.put("cep", cep);
                    enviar.put("telefone", telefone);
                    enviar.put("cpf", cpf);
                    enviar.put("email", email);
                    enviar.put("senha", senha);
                    enviar.put("tipoCliente","cliente");
                }catch(JSONException ex) {
                    ex.printStackTrace();
                }
                //Configurar a requisição
                JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST,
                        url,enviar, new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        //Recuperar a resposta do webservice
                        if (response.has("nome")) {
                            //Ajustar Manifest para a Snackbar aparecer sobre o teclado (na Activity)
                            //android:windowSoftInputMode="adjustResize"
                            Snackbar.make(tela_cadastro2.this, findViewById(R.id.tela), "Cadastrado", Snackbar.LENGTH_SHORT).show();
                        }
                        Log.d("APP_MYSQL", ">>>>>>>>>>>>>>>>> " + response.toString());

                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(tela_cadastro2.this, "Erro ao conectar", Toast.LENGTH_SHORT).show();
                        Log.d("APP_MYSQL", ">>>>>>>>>>>>>>>>> " + error.getMessage());
                    }
                });
                //Pedir para a requisição ser enviada e executada
                queue.add(request);
            }});
    }
}

