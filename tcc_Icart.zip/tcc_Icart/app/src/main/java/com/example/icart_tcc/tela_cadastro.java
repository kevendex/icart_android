package com.example.icart_tcc;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.snackbar.Snackbar;

import org.json.JSONException;
import org.json.JSONObject;

public class tela_cadastro extends AppCompatActivity {

    Button btVoltar;
    Button btCadastrar;
    EditText edtxtNome;
    EditText edtxtCEP;
    EditText edtxtTelefone;
    EditText edtxtCpf;
    EditText edtxtEmail;
    EditText edtxtSenha;
    EditText edtxtConfirmarSenha;
    EditText edUF;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide(); //tirar a barra
        setContentView(R.layout.activity_tela_cadastro);

        edUF = (EditText) findViewById(R.id.edUF);
        edtxtNome = (EditText) findViewById(R.id.edtxtNome);
        edtxtCEP = (EditText) findViewById(R.id.edtxtCEP);
        edtxtTelefone = (EditText) findViewById(R.id.edtxtTelefone);
        edtxtCpf = (EditText) findViewById(R.id.edtxtCpf);
        edtxtEmail = (EditText) findViewById(R.id.edtxtEmail);
        edtxtSenha = (EditText) findViewById(R.id.edtxtSenha);
        edtxtConfirmarSenha = (EditText) findViewById(R.id.edMunicipio);

        btVoltar = (Button) findViewById(R.id.btvoltar);
        btCadastrar = (Button) findViewById(R.id.btCadastrar);

        //Criar um objeto da classe Volley para configurar as requisições ao webservice
        RequestQueue queue = Volley.newRequestQueue(this);
        //Configuração do endpoint (url) da requisição
        String url = "http://10.0.2.2:5000/api/Produto";


        btCadastrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(edtxtSenha.getText().toString().equals(edtxtConfirmarSenha.getText().toString())) {
                    Intent intent = new Intent(getApplicationContext(), tela_cadastro2.class);
                    intent.putExtra("nome", edtxtNome.getText().toString());
                    intent.putExtra("uf", edUF.getText().toString());
                    intent.putExtra("cep", edtxtCEP.getText().toString());
                    intent.putExtra("telefone", edtxtTelefone.getText().toString());
                    intent.putExtra("cpf", edtxtCpf.getText().toString());
                    intent.putExtra("email", edtxtEmail.getText().toString());
                    intent.putExtra("senha", edtxtSenha.getText().toString());
                    startActivity(intent);
                }else{

                }
        }});



        btVoltar.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            Intent i = new Intent(tela_cadastro.this, MainActivity.class);
            startActivity(i);
        }
    });

    }
}